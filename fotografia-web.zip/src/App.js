
import FotografiaWeb from './FotografiaWeb';
export default function App() {
  return <FotografiaWeb />;
}
